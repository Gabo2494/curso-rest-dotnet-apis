//
//  Category.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/22/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation

struct Category: Codable{
    var id : Int16
    var name : String
    var image : String
    
    init(name: String) {
        self.name = name
        self.image = ""
        self.id = 0 
    }
}
