//
//  ApiConnectionManager.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/24/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
import Alamofire

enum Services : String{
    case PRODUCT = "Product/"
    case PRODUCT_BY_CATEGORY = "Product/ProductsByCategory/"
    case PRODUCT_BY_ORDER = "Product/ProductsByOrder/"
    case PRODUCT_SEARCH = "Product/Filter/"
    case PRODUCT_NEW = "Product/New/"
    
    case COMMENT_BY_PRODUCT = "Comment/CommentByProduct/"
    case CATEGORY = "Category"
    case ORDER_BY_USER = "Order/OrderByUser/"
    
    case GET_PRODUCT = "Product/1"
    
    
    case ORDER = "Order"
    case LOGIN = "User/Login"
    case CREATE_COMMENT = "Comment"
    case CREATE_USER = "User"
}

enum ServerUrl : String{
    case ECOMMERCE = "http://52.142.14.253:1004/Ecommerce/api/"
}

class Service {
    fileprivate var baseUrl = ""
    
    init(baseUrl: ServerUrl) {
        self.baseUrl = baseUrl.rawValue
    }
    
    func getAllItems<T : Decodable>(endPoint: String, callBack: @escaping ([T]?, Bool, String) -> Void) {
        
        AF.request("\(self.baseUrl)\(endPoint)", method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil, interceptor: nil)
        .response { responseData in
            debugPrint(responseData)
            debugPrint(responseData.response?.statusCode ?? "undefined statusCode")
            
            guard let data = responseData.data else {
                callBack(nil, false, "")
                return}
            do {
            let responseData = try JSONDecoder().decode([T].self, from: data)
                callBack(responseData, true,"")
            } catch {
                do {
                let message = try JSONDecoder().decode(Message.self, from: data)
                    callBack(nil, true,message.message)
                } catch {
                    callBack(nil, false, error.localizedDescription)
                }
            }
            
        }
    }
    
    func sendItems<T : Decodable>(data: [String:Any], endPoint: String, callBack: @escaping (T?, Bool, String) -> Void) {
        let headers: HTTPHeaders = [.accept("application/json"),
        .contentType("application/json")]
        AF.request("\(self.baseUrl)\(endPoint)", method: .post, parameters: data, encoding: JSONEncoding.default, headers: headers, interceptor: nil)
        .response { responseData in
            debugPrint(responseData)
            debugPrint(responseData.response?.statusCode ?? "undefined statusCode")
            
            guard let data = responseData.data else {
                callBack(nil, false, "")

                return}
            do {
            let responseData = try JSONDecoder().decode(T.self, from: data)
                callBack(responseData, true,"")
            } catch {
                do {
                let message = try JSONDecoder().decode(Message.self, from: data)
                    callBack(nil, true,message.message)
                } catch {
                    callBack(nil, false, error.localizedDescription)
                }
            }
            
        }
    }
    
    func createItems<T : Decodable>(data: [String:Any], endPoint: String, callBack: @escaping (T?, Bool, String) -> Void) {
        let headers: HTTPHeaders = [.accept("application/json"),
        .contentType("application/json")]
        AF.request("\(self.baseUrl)\(endPoint)", method: .post, parameters: data, encoding: JSONEncoding.default, headers: headers, interceptor: nil)
        .response { responseData in
            debugPrint(responseData)
            debugPrint(responseData.response?.statusCode ?? "undefined statusCode")
            
            if let code = responseData.response?.statusCode, code == 201{
                callBack(nil, true, "Se ha creado con éxito ")
                return
            }
            
            guard let data = responseData.data else {
                callBack(nil, false, "")

                return}
            do {
            let responseData = try JSONDecoder().decode(T.self, from: data)
                callBack(responseData, true,"")
            } catch {
                do {
                let message = try JSONDecoder().decode(Message.self, from: data)
                    callBack(nil, true,message.message)
                } catch {
                    callBack(nil, false, error.localizedDescription)
                }
            }
            
        }
    }
}
