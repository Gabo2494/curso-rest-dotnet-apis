//
//  Product.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/22/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation

struct Product: Codable{
    var id : Int16
    var name : String
    var image : String
    var price : Decimal
    var categories : [Category]
    var color : String
    var brand : Int16
    
   var description:[String:Any] {
        get {
            return ["id": self.id,
                    "price": self.price,
                    "name": self.name,
                ] as [String : Any]
        }
    }
    
    init(product: ProductDB){
        self.id = product.id
        self.name = product.name ?? ""
        self.image = product.image ?? ""
        self.price = product.price! as Decimal
        self.categories = []
        self.color = ""
        self.brand = product.brand 
    }
 }

struct ProductOrder{
    var product : ProductResponse
    var order : Int
}

struct ProductResponse: Codable{
    var id : Int16
    var name : String
    var image : String
    var price : Decimal
    var color : String
}
