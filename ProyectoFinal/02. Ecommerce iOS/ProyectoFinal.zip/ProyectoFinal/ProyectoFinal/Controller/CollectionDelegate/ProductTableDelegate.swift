//
//  ProductTableDelegate.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/28/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
import UIKit
class ProductTableDelegate: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    var vc : BaseViewController?
    var listProducts : [ProductDB]?
    var typeCell: String = "cell"
    var tableView: UITableView?
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.listProducts?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : ShoppingCarItemTableViewCell = tableView.dequeueReusableCell(withIdentifier: self.typeCell, for: indexPath) as! ShoppingCarItemTableViewCell
        if let listData = self.listProducts{
            cell.setData(data: listData[indexPath.row])
            cell.delegateRemove = self
        }
        return cell
    }
}

extension ProductTableDelegate: DeleteSelfCellProtocol{
    func delete<T>(data: T) {
        if let _ = listProducts,
            let productData = data as? ProductDB{
            listProducts!.removeAll{$0 == productData}
        }
        DispatchQueue.main.async {
            self.tableView!.reloadData()
        }
    }
    
    
}
