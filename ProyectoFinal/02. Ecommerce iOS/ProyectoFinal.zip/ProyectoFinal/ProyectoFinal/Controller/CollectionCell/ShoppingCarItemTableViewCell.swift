//
//  ShoppingCarItemTableViewCell.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/28/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class ShoppingCarItemTableViewCell: UITableViewCell {
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var totalAmountLbl: UILabel!
    @IBOutlet weak var counterLbl: UILabel!
    @IBOutlet weak var counterStepper: UIStepper!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var containerView: UIView!
    
    var data: ProductDB?
    var delegateRemove: DeleteSelfCellProtocol?
    
    func setData(data: ProductDB){
        self.data = data
        self.nameLbl.text? = data.name ?? ""
        let unitPrice : Decimal = data.price as Decimal? ?? 0
        self.priceLbl.text? = "Precio: ₡\(unitPrice )"
        
        if let image = DesignManager.base64ToImage(base64String: data.image){
            self.productImage.image =  image
        }
        
        self.totalAmountLbl.text? = "Precio: ₡\(unitPrice * Decimal(self.counterStepper.value))"
        self.counterLbl.text? = "\(Int(self.counterStepper.value))"
        self.setDesign()
    }
    
    @IBAction func deleteItem(_ sender: Any) {
        if let dataObj = self.data{
            CoreDataManager.deleteProduct(id: dataObj.id)
            if let delegate =  self.delegateRemove{
                delegate.delete(data: dataObj)
            }
        }
    }
    
    func setDesign(){
        DesignManager.viewDesign(element: self.containerView, type: .BORDER)
    }
}
