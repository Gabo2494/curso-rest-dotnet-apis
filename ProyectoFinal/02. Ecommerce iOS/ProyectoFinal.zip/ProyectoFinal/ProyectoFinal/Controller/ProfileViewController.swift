//
//  ProfileViewController.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/29/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class ProfileViewController: BaseViewController {

    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    @IBOutlet weak var birthdayLbl: UILabel!
    
    @IBOutlet weak var principalCollection: UICollectionView!
    @IBOutlet weak var subTitleView1: UIView!
    @IBOutlet weak var productsContainerView: UIView!
    @IBOutlet weak var principalView: UIView!
    
    var currentUser: User?
    
    var productCollectionDelegate = ProductCollectionDelegate()
    
    var listProducts : [ProductOrder] = []{
        didSet{
            self.productCollectionDelegate.listProductsCategory = self.listProducts
            self.principalCollection.reloadData()
        }
    }
    @IBAction func logoutAction(_ sender: Any) {
        CoreDataManager.deleteAllProduct()
        UserDefaultsManager.removeUserData()
        
        self.showMessage(title: "Sesión finalizada", message: "Hasta pronto!!", button: "Continuar", completion:
            {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.navigationController?.popToRootViewController(animated: true)
                }
        })
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.productCollectionDelegate.vc = self
        self.productCollectionDelegate.sendCommentProduct = true
        self.principalCollection.dataSource = self.productCollectionDelegate
        self.principalCollection.delegate = self.productCollectionDelegate
        
        self.currentUser = UserDefaultsManager.getUserData()
        
        self.nameLbl.text = self.currentUser?.name
        self.emailLbl.text = self.currentUser?.email
        self.birthdayLbl.text = "24/08/1994"
        
        self.setData()
        self.setDesign()
    }
    
    func setDesign(){
        DesignManager.viewDesign(element: self.principalView, type: .PRINCIPAL)
        DesignManager.viewDesign(element: self.subTitleView1, type: .SUBTITLE)
        
        DesignManager.viewDesign(element: self.productsContainerView, type: .PRODUCT_COLLECTION_CONTAINER)
    }
}


extension ProfileViewController{
    func setData(){
        self.showLoader()
        DataAccessManager.getOrder(endPoint: "\(Services.ORDER_BY_USER.rawValue)\(self.currentUser!.id)", completition : self.setOrder, onError: self.showError)
    }
    
    func setOrder(data : [OrderResponse]?){
        DispatchQueue.main.async {
            var tmpProduct: [ProductOrder] = []
            if let list = data{
                for item in list{
                    for product in item.products {
                        tmpProduct.append(ProductOrder(product: product, order: item.id) )
                    }
                }
                self.listProducts = tmpProduct
            }
            self.hideLoader()
        }
    }
}
