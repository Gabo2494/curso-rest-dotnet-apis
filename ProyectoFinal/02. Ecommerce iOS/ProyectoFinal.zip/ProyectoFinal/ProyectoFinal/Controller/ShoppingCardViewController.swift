//
//  ShoppingCardViewController.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/28/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class ShoppingCardViewController: BaseViewController {
    
    @IBOutlet weak var principalView: UIView!
    @IBOutlet weak var tableViewContainer: UIView!
    @IBOutlet weak var productTableView: UITableView!
    @IBOutlet weak var sendOrderBtn: UIButton!
    
    var productTableDelegate = ProductTableDelegate()
    
    var listProducts : [ProductDB] = []{
        didSet{
            productTableDelegate.listProducts = self.listProducts
            self.productTableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.productTableDelegate.vc = self
        self.productTableView.dataSource = self.productTableDelegate
        self.productTableView.delegate = self.productTableDelegate
        
        self.productTableDelegate.tableView = self.productTableView
        
        self.title = "Carrito"
        
        self.setDesign()
        self.setData()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    func setDesign(){
        DesignManager.viewDesign(element: self.tableViewContainer, type: .PRODUCT_COLLECTION_CONTAINER)
        DesignManager.buttonDesign(element: self.sendOrderBtn, type: .FORM)
        //DesignManager.viewDesign(element: self.productsContainerView, type: .PRODUCT_COLLECTION_CONTAINER)
        //DesignManager.navigationBarDesign(element: self.navigationController!.navigationBar, type: .PRINCIPAL)
    }

    
    @IBAction func sendOrderAction(_ sender: Any) {
        if let userData = UserDefaultsManager.getUserData(){
            let paymentVC = (UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PaymentViewController") as! PaymentViewController)
            self.navigationController?.pushViewController(paymentVC, animated: true)

        }
        else{
            let loginVC = (UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController)
            self.navigationController?.pushViewController(loginVC, animated: true)
        }
    }
    
}

extension ShoppingCardViewController{
    func setData(){
        self.showLoader()
        self.listProducts = CoreDataManager.getProduct()
        if self.listProducts.count == 0{
            self.sendOrderBtn.isEnabled = false
        }
        self.hideLoader()
    }
}
