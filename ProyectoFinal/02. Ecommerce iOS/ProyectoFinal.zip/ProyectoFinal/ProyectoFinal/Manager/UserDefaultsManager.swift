//
//  UserDefaultsManager.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/23/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation

enum keyObject: String{
    case nameUser =  "nameUser"
    case emailUser =  "emailUser"
    case tokenUser =  "tokenUser"
    case idUser =  "idUser"
}

class UserDefaultsManager{
    
    static func getUserData() -> User?{
        let defaults = UserDefaults.standard
        if let name = defaults.object(forKey: keyObject.nameUser.rawValue) as? String,
            let email = defaults.object(forKey: keyObject.emailUser.rawValue) as? String,
            let token = defaults.object(forKey: keyObject.tokenUser.rawValue) as? String,
            let id = defaults.object(forKey: keyObject.idUser.rawValue) as? Int16{
            
            let user: User = User.init(name: name, email: email, token: token, id: id)
            
            return user
        }
        return nil
    }
    
    static func setUserData(user: User){
        self.removeUserData()
        let defaults = UserDefaults.standard
        
        defaults.set(user.name, forKey: keyObject.nameUser.rawValue)
        defaults.set(user.email, forKey: keyObject.emailUser.rawValue)
        defaults.set(user.token, forKey: keyObject.tokenUser.rawValue)
        
        defaults.set(user.id, forKey: keyObject.idUser.rawValue)
        
        defaults.synchronize()
    }
    
    static func removeUserData(){
        
        let defaults = UserDefaults.standard
        
        defaults.removeObject(forKey: keyObject.nameUser.rawValue)
        defaults.removeObject(forKey: keyObject.emailUser.rawValue)
        defaults.removeObject(forKey: keyObject.tokenUser.rawValue)
        defaults.removeObject(forKey: keyObject.idUser.rawValue)
        
        defaults.synchronize()
    }
    
    
    
}
