//
//  BaseViewController.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/23/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController, UITextFieldDelegate {

    let loaderVC = (UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoaderViewController") as! LoaderViewController)
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // self.hideKeyboardWhenTappedAround()
    }
    
    func showLoader(){
        DispatchQueue.main.async {
            self.navigationController?.view.addSubview(self.loaderVC.view)
        }
    }
    
    func hideLoader(){
        DispatchQueue.main.async {
            self.loaderVC.willMove(toParent: nil)
            self.loaderVC.view.removeFromSuperview()
            self.loaderVC.removeFromParent()
        }
    }
    
    func hideLoader(action: UIAlertAction){
        DispatchQueue.main.async {
            self.loaderVC.willMove(toParent: nil)
            self.loaderVC.view.removeFromSuperview()
            self.loaderVC.removeFromParent()
        }
    }
    
    func showError(error: NSError){
        DispatchQueue.main.async {
            self.showMessage()
        }
    }
    
    func showError(error: String){
        DispatchQueue.main.async {
            if error.count > 0 {
                self.showMessage(title: "Error", message: error)
            }
            else {
                self.showMessage()
            }
        }
    }
    
    func showMessage(title: String = "Atención",
                     message: String = "Ha occurrido un error, intente más tarde.",
                     button: String = "Aceptar",
                     completion: (() -> Void)? = nil){

        // create the alert
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)

        // add the actions (buttons)
        alert.addAction(UIAlertAction(title: button, style: UIAlertAction.Style.default, handler: self.hideLoader))

        // show the alert
        self.present(alert, animated: true, completion: completion)
    }
    
    func showMessageTwoOptions(){

        // create the alert
        let alert = UIAlertController(title: "Notice", message: "Lauching this missile will destroy the entire universe. Is this what you intended to do?", preferredStyle: UIAlertController.Style.alert)

        // add the actions (buttons)
        alert.addAction(UIAlertAction(title: "Remind Me Tomorrow", style: UIAlertAction.Style.default, handler: self.hideLoader))
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Launch the Missile", style: UIAlertAction.Style.destructive, handler: self.hideLoader))

        // show the alert
        self.present(alert, animated: true, completion: nil)
    }
    
    func openShoppingCart(){
        let productVC = (UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ShoppingCardViewController") as! ShoppingCardViewController)
        self.navigationController?.pushViewController(productVC, animated: true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        /*if textField == txtUser{
            self.txtPassword.becomeFirstResponder()
        }
        else{*/
            self.view.endEditing(true)
        //}
        return true
    }

}
