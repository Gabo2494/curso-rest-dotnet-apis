//
//  ProductCollectionDelegate.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/22/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
import UIKit

class ProductCollectionDelegate: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate,UICollectionViewDelegateFlowLayout{
    
    var vc : BaseViewController?
    var listProducts : [Product]?
    var listProductsCategory : [ProductOrder]?
    var typeCell: String = "cell"
    
    var sendCommentProduct: Bool = false
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.sendCommentProduct ? self.listProductsCategory?.count ?? 0 : self.listProducts?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : ProductCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: self.typeCell, for: indexPath) as! ProductCollectionViewCell
        if self.sendCommentProduct
        {
            if let listData = self.listProductsCategory{
                cell.setData(data: listData[indexPath.row].product)
            }
        }
        else{
            if let listData = self.listProducts{
                cell.setData(data: listData[indexPath.row])
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.width - 20, height: 150)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if self.sendCommentProduct{
            let commentVC = (UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CommentViewController") as! CommentViewController)
            commentVC.product = self.listProductsCategory![indexPath.row].product
            commentVC.orderID = self.listProductsCategory![indexPath.row].order
            vc?.navigationController?.pushViewController(commentVC, animated: true)
        }
        else{
            let productVC = (UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProductViewController") as! ProductViewController)
            productVC.product = self.listProducts![indexPath.row]
            vc?.navigationController?.pushViewController(productVC, animated: true)
        }
    }
    
    
}
