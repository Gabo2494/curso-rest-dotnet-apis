//
//  CategoryCollectionViewCell.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/22/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var categoryImage: UIImageView!
    @IBOutlet weak var principalView: UIView!
    @IBOutlet weak var nameLbl: UILabel!
    
    
    func setData(data: Category){
        self.nameLbl.text? = data.name
        if let image = DesignManager.base64ToImage(base64String: data.image){
            self.categoryImage.image =  image
        }
        self.setDesign()
    }
    
    func setDesign(){
        DesignManager.viewDesign(element: self.principalView, type: .BORDER_CELL)
    }
    
}
