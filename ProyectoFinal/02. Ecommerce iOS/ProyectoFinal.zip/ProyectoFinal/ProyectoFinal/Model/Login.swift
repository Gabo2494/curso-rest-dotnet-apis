//
//  Login.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/28/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
struct Login: Codable{
    var email : String
    var password : String
    
    
    var description:[String:Any] {
        get {
            return ["email":self.email, "password": self.password] as [String : Any]
        }
    }
    
}
