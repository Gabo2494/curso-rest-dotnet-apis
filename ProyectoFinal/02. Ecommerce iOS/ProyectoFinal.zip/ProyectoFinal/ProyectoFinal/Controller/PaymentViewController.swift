//
//  PaymentViewController.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/29/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class PaymentViewController: BaseViewController {
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    @IBOutlet weak var birthdayLbl: UILabel!
    
    @IBOutlet weak var cardNumberTxt: UITextField!
    @IBOutlet weak var dateTxt: UITextField!
    @IBOutlet weak var cvvTxt: UITextField!
    @IBOutlet weak var paymentBtn: UIButton!
    @IBOutlet weak var principalView: UIView!
    
    var currentUser: User?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.cardNumberTxt.delegate = self
        self.cvvTxt.delegate = self
        self.dateTxt.delegate = self
        self.currentUser = UserDefaultsManager.getUserData()
        
        self.nameLbl.text = self.currentUser?.name
        self.emailLbl.text = self.currentUser?.email
        self.birthdayLbl.text = "24/08/1994"
        self.setDesign()
    }
    
    func setDesign()
    {
        DesignManager.buttonDesign(element: self.paymentBtn, type: .FORM)
    }
    
    @IBAction func sendOrderAction(_ sender: Any) {
        if self.cardNumberTxt.text!.count < 8{
            self.showMessage(title: "Datos incorrectos", message: "Tarjeta invalida", button: "Continuar")
        }
        else if self.dateTxt.text!.count != 5 {
            self.showMessage(title: "Datos incorrectos", message: "Vencimiento en formato MM/YY", button: "Continuar")
        }
        else if self.cvvTxt.text!.count != 3{
            self.showMessage(title: "Datos incorrectos", message: "CVV 3 dígitos", button: "Continuar")
        }
        else{
            let dataPayment = PaymentData(card: self.cardNumberTxt.text!,
                                           expiration: self.dateTxt.text!,
                                           cvv: self.cvvTxt.text!)
            
            if let user = self.currentUser{
                let products = CoreDataManager.getProduct()
                var total: Decimal = 0
                for item in products {
                    total = total + (item.price as Decimal? ?? 0)
                }
                self.showLoader()
                
                let order = Order(payment: dataPayment, user: user, productsData: products, total: total)
                let params = order.description
                
                DataAccessManager.sendOrder(parameters: params,
                                        completition: self.orderCreatedSuccessful,
                                        onError: self.showError)
                
            }
            
        }
    }
    
    func orderCreatedSuccessful(data : String?){
        DispatchQueue.main.async {
            if let _ = data{
                self.showMessage(title: "Orden creada", message: "\(data!)la orden de compra!", button: "Aceptar", completion:{
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        CoreDataManager.deleteAllProduct()
                        self.hideLoader()
                        self.navigationController?.popToRootViewController(animated: true)
                    }
                })
            }
        }
    }
    
    

}
