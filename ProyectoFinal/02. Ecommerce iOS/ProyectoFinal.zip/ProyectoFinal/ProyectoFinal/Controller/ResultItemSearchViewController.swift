//
//  ResultItemSearchViewController.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/22/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class ResultItemSearchViewController: BaseViewController {

    @IBOutlet weak var principalCollection: UICollectionView!
    @IBOutlet weak var subTitleView1: UIView!
    @IBOutlet weak var productsContainerView: UIView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var principalView: UIView!
    @IBOutlet weak var filterContainerView: UIView!
    @IBOutlet weak var firstFilterView: UIView!
    @IBOutlet weak var secondFilterView: UIView!
    @IBOutlet weak var filterViewHeight: NSLayoutConstraint!
    @IBOutlet weak var filterBtn: UIButton!
    @IBOutlet weak var filterApplyBtn: UIButton!
    @IBOutlet weak var searchTxt: UITextField!
    
    @IBOutlet weak var categoryLbl: UILabel!
    var productCollectionDelegate = ProductCollectionDelegate()
    var categorySelect : Category?
    
    var listProducts : [Product] = []{
        didSet{
            self.productCollectionDelegate.listProducts = self.listProducts
            self.principalCollection.reloadData()
        }
    }
    
    var filterIsHidden: Bool = false{
        didSet{
            self.firstFilterView.isHidden = self.filterIsHidden
            self.secondFilterView.isHidden = self.filterIsHidden
            self.filterApplyBtn.isHidden = self.filterIsHidden
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.productCollectionDelegate.vc = self
        self.principalCollection.dataSource = self.productCollectionDelegate
        self.principalCollection.delegate = self.productCollectionDelegate
        self.searchTxt.delegate = self
        self.title = "Nueva búsqueda"
        self.categoryLbl.text = self.categorySelect?.name ?? "Todas"
        self.filterIsHidden = true
        
        self.setDesign()
        self.setData()
    }
    
    func setDesign(){
        DesignManager.viewDesign(element: self.principalView, type: .PRINCIPAL)
        DesignManager.viewDesign(element: self.headerView, type: .SEARCH_BAR)
        DesignManager.viewDesign(element: self.subTitleView1, type: .SUBTITLE)
        
        DesignManager.viewDesign(element: self.productsContainerView, type: .PRODUCT_COLLECTION_CONTAINER)
        DesignManager.viewDesign(element: self.filterContainerView, type: .FILTER_CONTAINER)
        DesignManager.buttonDesign(element: self.filterApplyBtn, type: .FORM)
        
        self.filterViewHeight.constant = 30
    }
    func showFilterArea() {
        UIView.transition(with: self.view, duration: 0.35, options: [.transitionCrossDissolve], animations: {
            self.filterViewHeight.constant = self.filterIsHidden ? 160 : 30
            self.filterBtn.setImage(UIImage.init(systemName: "arrowtriangle.\(self.filterIsHidden ? "up" : "down").fill"), for: .normal)
            self.filterIsHidden = !self.filterIsHidden
            
        })
    }
    
    @IBAction func shoppingCartAction(_ sender: Any) {
        
    }
    @IBAction func OpenFilterAction(_ sender: Any) {
       // self.showFilterArea()
        if self.searchTxt.text!.count > 0{
            self.searchProducts()
        }
    }
    
    fileprivate func searchProducts() {
        self.showLoader()
        self.view.endEditing(true)
        DataAccessManager.getProducts(endPoint: "\(Services.PRODUCT_SEARCH.rawValue)\(self.searchTxt.text!)" , completition : self.setProducts, onError: self.showError)
    }
    
    @IBAction func applyFilterAction(_ sender: Any) {
        //self.showFilterArea()
        if self.searchTxt.text!.count > 0{
            self.searchProducts()
        }
    }
    
}

//MARK: Setting Data

extension ResultItemSearchViewController{
    func setData(){
        self.showLoader()
        if let category = self.categorySelect{
            DataAccessManager.getProductsCategory(category: category, completition : self.setProducts, onError: self.showError)
        }
        else{
            DataAccessManager.getProducts(endPoint: Services.PRODUCT.rawValue, completition : self.setProducts, onError: self.showError)
        }
    }
    
    func setProducts(data : [Product]?){
        DispatchQueue.main.async {
            if let list = data{
                self.listProducts = list
            }
            self.categorySelect = nil
            self.hideLoader()
        }
    }
}
