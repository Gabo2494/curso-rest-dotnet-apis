//
//  Token.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/28/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
struct Token: Codable{
    var email : String
    var token : String
    var id : Int16

    var description:[String:Any] {
        get {
            return ["email":self.email, "token": self.token, "id": self.id] as [String : Any]
        }
    }
    
}
