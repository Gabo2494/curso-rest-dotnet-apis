//
//  CommentCollectionViewCell.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/23/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class CommentCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var commentImage: UIImageView!
    @IBOutlet weak var likeImage: UIImageView!
    @IBOutlet weak var emailLbl: UILabel!
    @IBOutlet weak var descriptionLbl: UILabel!
    
    @IBOutlet weak var containerView: UIView!
    
    func setData(data: Comment){
        self.emailLbl.text? = data.user
        self.descriptionLbl.text? = data.description
        self.likeImage.image = UIImage.init(systemName: "hand.\(data.like ? "thumbsup" : "thumbsdown").fill")
        if let image = DesignManager.base64ToImage(base64String: data.image),
            let pngData = image.pngData(),
            pngData.count > 0{
            
            self.commentImage.image =  image
        }
        self.setDesign()
    }
    
    func setDesign(){
        //DesignManager.viewDesign(element: self.containerView, type: .BORDER_CELL)
    }
    
}
