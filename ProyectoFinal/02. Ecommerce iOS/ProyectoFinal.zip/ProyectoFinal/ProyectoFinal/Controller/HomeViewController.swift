//
//  ViewController.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/22/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class HomeViewController: BaseViewController {

    @IBOutlet weak var principalCollection: UICollectionView!
    @IBOutlet weak var categoriesCollection: UICollectionView!
    @IBOutlet weak var principalView: UIView!
    @IBOutlet weak var subTitleView1: UIView!
    @IBOutlet weak var subTitleView2: UIView!
    
    @IBOutlet weak var productsContainerView: UIView!
    
    var productCollectionDelegate = ProductCollectionDelegate()
    var categoryCollectionDelegate = CategoryCollectionDelegate()
    
    var categoryList : [Category] = []{
        didSet{
            categoryCollectionDelegate.categoryList = self.categoryList
            self.categoriesCollection.reloadData()
        }
    }
    
    var listProducts : [Product] = []{
        didSet{
            productCollectionDelegate.listProducts = self.listProducts
            self.principalCollection.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.productCollectionDelegate.vc = self
        self.principalCollection.dataSource = self.productCollectionDelegate
        self.principalCollection.delegate = self.productCollectionDelegate
        
        self.categoryCollectionDelegate.vc = self
        self.categoriesCollection.dataSource = self.categoryCollectionDelegate
        self.categoriesCollection.delegate = self.categoryCollectionDelegate
        
        self.title = "Inicio"
        CoreDataManager.deleteAllProduct()
        self.setDesign()
        self.setData()
        
    }
    
    
    func setDesign(){
        DesignManager.viewDesign(element: self.subTitleView1, type: .SUBTITLE)
        DesignManager.viewDesign(element: self.subTitleView2, type: .SUBTITLE)
        DesignManager.viewDesign(element: self.principalView, type: .PRINCIPAL)
        DesignManager.viewDesign(element: self.productsContainerView, type: .PRODUCT_COLLECTION_CONTAINER)
        DesignManager.navigationBarDesign(element: self.navigationController!.navigationBar, type: .PRINCIPAL)
    }
    
    @IBAction func profileAction(_ sender: Any) {
        if let _ = UserDefaultsManager.getUserData(){
            let profileVC = (UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController)
            self.navigationController?.pushViewController(profileVC, animated: true)
        }
        else{
            let loginVC = (UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController)
            self.navigationController?.pushViewController(loginVC, animated: true)
        }
        
    }
    @IBAction func searchAction(_ sender: Any) {
        
    }
    @IBAction func shoppingCartAction(_ sender: Any) {
        self.openShoppingCart()
        
    }

}

//MARK: Setting Data

extension HomeViewController{
    func setData(){
        self.showLoader()
        DataAccessManager.getCategories(completition : self.setCategories, onError: self.showError)
    }
    
    func setCategories(data : [Category]?){
        DispatchQueue.main.async {
            if let list = data{
                self.categoryList = list
            }
            DataAccessManager.getProducts(endPoint: Services.PRODUCT_NEW.rawValue, completition : self.setProducts, onError: self.showError)
        }
    }
    
    func setProducts(data : [Product]?){
        DispatchQueue.main.async {
            if let list = data{
                self.listProducts = list
            }
            self.hideLoader()
        }
    }
    
    
    
}

