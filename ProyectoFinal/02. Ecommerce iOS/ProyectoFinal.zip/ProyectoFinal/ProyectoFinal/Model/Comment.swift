//
//  Comment.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/23/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation

struct Comment: Codable{
    var id : Int16
    var productId : Int16
    var orderId : Int16
    var user : String
    var description : String
    var image : String
    var like : Bool
    
   var descriptionComment:[String:Any] {
       get {
           return ["id": self.id,
                   "productId": self.productId,
                   "orderId": self.orderId,
                   "user": self.user,
                   "description": self.description,
                   "image": self.image,
                   "like": self.like
               ] as [String : Any]
       }
   }
    
}
