//
//  DeleteSelfCellProtocol.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/29/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation

protocol DeleteSelfCellProtocol {
    func delete<T>(data: T)
}
