//
//  LoginViewController.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/28/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class LoginViewController: BaseViewController {

    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var passwordTxt: UITextField!
    @IBOutlet weak var nameTxt: UITextField!
    @IBOutlet weak var birthdayTxt: UITextField!
    @IBOutlet weak var registerBtn: UIButton!
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var principalView: UIView!
    
    @IBOutlet weak var personalInformationView: UIView!
    
    var isLogin = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.passwordTxt.delegate = self
        self.nameTxt.delegate = self
        self.emailTxt.delegate = self
        self.birthdayTxt.delegate = self
        self.passwordTxt.textContentType = .oneTimeCode
        self.personalInformationView.isHidden = true
       
        self.setDesign()
    }
    
    func setDesign(){
        DesignManager.buttonDesign(element: self.loginBtn, type: .FORM)
    }
    
    @IBAction func registerAction(_ sender: Any) {
        UIView.transition(with: self.view, duration: 0.2, options: [.transitionCrossDissolve], animations: {
            self.registerBtn.isHidden = true
            self.personalInformationView.isHidden = false
            self.loginBtn.setTitle("Registarse", for: .normal)
            self.isLogin = false
        })
    }
    
    
    func registerAction() {
       if self.emailTxt.text!.count < 8{
           self.showMessage(title: "Datos incorrectos", message: "Email muy corto", button: "Continuar")
       }
       else if self.passwordTxt.text!.count < 8{
           self.showMessage(title: "Datos incorrectos", message: "Contraseña debe tener mínimo 8 caracteres", button: "Continuar")
       }
       else if self.nameTxt.text!.count < 8{
           self.showMessage(title: "Datos incorrectos", message: "Nombre muy corto", button: "Continuar")
       }
       else{
           let dataRegister = Register(name: self.nameTxt.text!,
                                       email: self.emailTxt.text!,
                                       password: self.passwordTxt.text!)
           self.showLoader()
           DataAccessManager.CreateUser(parameters: dataRegister.description,
                                        completition: self.loginWihtNewUSer,
                                        onError: self.showError)
            
           
       }
    }
    
    func loginWihtNewUSer(data : Register?){
        DispatchQueue.main.async {
            if let _ = data{
                let dataLogin = Login(email: self.emailTxt.text!, password: self.passwordTxt.text!)
                let parameters = dataLogin.description
                DataAccessManager.Login(parameters: parameters,
                                        completition: self.saveToken,
                                        onError: self.showError)
            }
            else{
                self.showError(error: "")
            }
        }
    }
    
    func loginAction(){
       if self.emailTxt.text!.count < 8{
           self.showMessage(title: "Datos incorrectos", message: "Email muy corto", button: "Continuar")
        }
        else if self.passwordTxt.text!.count < 8{
           self.showMessage(title: "Datos incorrectos", message: "Contraseña debe tener mínimo 8 caracteres", button: "Continuar")
        }
        else{
            self.showLoader()
            let dataLogin = Login(email: self.emailTxt.text!, password: self.passwordTxt.text!)
            let parameters = dataLogin.description
            DataAccessManager.Login(parameters: parameters,
                                    completition: self.saveToken,
                                    onError: self.showError)
        }
    }
    
    
    @IBAction func loginAction(_ sender: Any) {
        if isLogin{
            self.loginAction()
        }
        else{
            self.registerAction()
        }
    }
    
    func saveToken(data : Token?){
        DispatchQueue.main.async {
            if let token = data{
                let user = User(name: "Usuario", email: token.email, token: token.token, id : token.id)
                UserDefaultsManager.setUserData(user: user)
                self.showMessage(title: "Bienvenido", message: "Login exitoso!!", button: "Continuar", completion:
                    {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            self.navigationController?.popToRootViewController(animated: true)
                        }
                })
            }
        }
    }
    
    @IBAction func endEditing(_ sender: Any) {
        view.endEditing(true)
    }
    

}
