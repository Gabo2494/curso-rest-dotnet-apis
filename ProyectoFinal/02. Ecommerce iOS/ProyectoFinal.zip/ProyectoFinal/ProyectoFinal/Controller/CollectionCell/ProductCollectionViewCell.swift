//
//  ProductCollectionViewCell.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/22/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class ProductCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var priceLbl: UILabel!
    
    @IBOutlet weak var containerView: UIView!
    
    func setData(data: Product){
        self.nameLbl.text? = data.name
        self.priceLbl.text? = "Precio: ₡\(data.price)"
        
        if let image = DesignManager.base64ToImage(base64String: data.image){
            self.productImage.image =  image
        }
        self.setDesign()
    }
    
    func setData(data: ProductResponse){
        self.nameLbl.text? = data.name
        self.priceLbl.text? = "Precio: ₡\(data.price)"
        
        if let image = DesignManager.base64ToImage(base64String: data.image){
            self.productImage.image =  image
        }
        self.setDesign()
    }
    
    func setDesign(){
        DesignManager.viewDesign(element: self.containerView, type: .BORDER_CELL)
    }
}
