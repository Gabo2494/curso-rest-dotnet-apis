//
//  User.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/23/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
struct User: Codable{
    var name : String
    var email : String
    var token : String
    var id : Int16
    
    init(name: String, email: String, token: String, id : Int16) {
        self.name = name
        self.email = email
        self.token = token
        self.id = id
    }
    
    var description:[String:Any] {
        get {
            return ["email":self.email, "token": self.token] as [String : Any]
        }
    }
}
