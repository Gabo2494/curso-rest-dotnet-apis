//
//  CommentViewController.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/29/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class CommentViewController: BaseViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate  {
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var priceLbl: UILabel!

    @IBOutlet weak var principalView: UIView!
    @IBOutlet weak var productContainerView: UIView!

    @IBOutlet weak var commentTxt: UITextField!
    @IBOutlet weak var likeBtn: UIButton!
    @IBOutlet weak var notlikeBtn: UIButton!
    @IBOutlet weak var sendBtn: UIButton!
    @IBOutlet weak var takePictureBtn: UIButton!
    @IBOutlet weak var colorLbl: UILabel!
    @IBOutlet weak var commentImage: UIImageView!
    
    var imagePicker: UIImagePickerController!
    
    var product : ProductResponse? = nil
    
    var orderID: Int = 0
    
    var like: Bool = true
    
    var imageLoad: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setDesign()
        if let data = self.product {
            self.setDataProduct(product: data)
        }
        self.commentTxt.delegate = self
    }
    func setDesign(){
        DesignManager.viewDesign(element: self.productContainerView, type: .BORDER_CELL)
        DesignManager.viewDesign(element: self.principalView, type: .PRINCIPAL)
        DesignManager.buttonDesign(element: self.sendBtn, type: .FORM)
        self.buttonLike()
    }
    func setDataProduct(product: ProductResponse){
        self.title =  product.name
        self.nameLbl.text? = product.name
        self.priceLbl.text? = "Precio: ¢\(product.price)"
        self.colorLbl.text? = "Color: ¢\(product.color)"
    }
    
    func buttonLike(){
        self.likeBtn.tintColor = self.like ? .systemBlue : .systemGray3
        self.notlikeBtn.tintColor = self.like ? .systemGray3 : .systemBlue
        
    }
    
    
    @IBAction func likeAction(_ sender: Any) {
        self.like = true
        self.buttonLike()
    }
    @IBAction func notLikeAction(_ sender: Any) {
        self.like = false
        self.buttonLike()
    }
    @IBAction func sendAction(_ sender: Any) {
        let user = UserDefaultsManager.getUserData()
        var newComment = Comment(id: 0,
                                 productId: product!.id,
                                 orderId: Int16(self.orderID),
                                 user: user!.email,
                                 description: self.commentTxt.text!,
                                 image: self.imageLoad ?? "",
                                 like: self.like)
        self.showLoader()
        DataAccessManager.sendComment(parameters: newComment.descriptionComment,
                                      completition: self.commentCreatedSuccessful,
                                      onError: self.showError)
    }
    
    func commentCreatedSuccessful(data : String?){
        DispatchQueue.main.async {
            if let _ = data{
                self.showMessage(title: "Comentario enviado", message: "\(data!)el comentario!", button: "Aceptar", completion:{
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        self.hideLoader()
                        self.navigationController?.popToRootViewController(animated: true)
                    }
                })
            }
        }
    }
    
    @IBAction func takePictureAction(_ sender: Any) {
        imagePicker =  UIImagePickerController()
        imagePicker.delegate = self
        if !UIImagePickerController.isSourceTypeAvailable(.camera){
            imagePicker.sourceType = .photoLibrary//.camera
        }
        else{
            imagePicker.sourceType = .photoLibrary
        }
        present(imagePicker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imagePicker.dismiss(animated: true, completion: nil)
        if let image = info[.originalImage] as? UIImage{
            commentImage.image =  image
            if let imageConverted = image.toBase64(format: ImageFormat.png){
                self.imageLoad = "data:image/png;base64,\(imageConverted)"
            }
            
        }
    }

    
}

public enum ImageFormat {
    case png
    case jpeg(CGFloat)
}

extension UIImage {
    public func toBase64(format: ImageFormat) -> String? {
        var imageData: Data?

        switch format {
        case .png:
            imageData = self.pngData()
        case .jpeg(let compression):
            imageData = self.jpegData(compressionQuality: compression)
        }

        return imageData?.base64EncodedString()
    }
}
