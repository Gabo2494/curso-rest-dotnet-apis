//
//  Register.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/28/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
struct Register: Codable{
    var name : String
    var email : String
    var password : String
    
    var description:[String:Any] {
        get {
            return ["email":self.email, "password": self.password, "name": self.name, "birthday": "1994-08-24T00:00:00"] as [String : Any]
        }
    }
}
