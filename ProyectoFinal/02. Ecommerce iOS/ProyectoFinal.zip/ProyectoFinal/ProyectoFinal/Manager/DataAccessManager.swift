//
//  DataAccessManager.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/23/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation

class DataAccessManager{
    
    
    static func getProducts<T : Decodable>(endPoint: String, completition: @escaping ([T]?) -> Void,
                                           onError: ((String) -> Void)?){
        DispatchQueue.main.async {
           let service = Service(baseUrl: .ECOMMERCE)
            let function = {(data:[T]?, status: Bool, message:String) -> Void in
                if status {
                    completition(data)
                }
                else{
                    if let errorFuntion = onError{
                        errorFuntion("")
                    }
                }
            }
            service.getAllItems(endPoint: endPoint, callBack: function)
        }
    }
    
    static func getCategories<T : Decodable>(completition:@escaping ([T]?) -> Void,
                                             onError: ((String) -> Void)?){
        
        DispatchQueue.main.async {
           let service = Service(baseUrl: .ECOMMERCE)
            let function = {(data:[T]?, status: Bool, message:String) -> Void in
                if status {
                    completition(data)
                }
                else{
                    if let errorFuntion = onError{
                        errorFuntion("")
                    }
                }
            }
            service.getAllItems(endPoint: Services.CATEGORY.rawValue, callBack: function)
        }
        
    }
    
    static func getProductsCategory<T : Decodable>(category: Category,
                                    completition:@escaping ([T]?) -> Void,
                                    onError: ((String) -> Void)?){
        DispatchQueue.main.async {
           let service = Service(baseUrl: .ECOMMERCE)
            let function = {(data:[T]?, status: Bool, message:String) -> Void in
                if status {
                    completition(data)
                }
                else{
                    if let errorFuntion = onError{
                        errorFuntion("")
                    }
                }
            }
            print( "\(Services.PRODUCT_BY_CATEGORY.rawValue)\(category.id)")
            service.getAllItems(endPoint: "\(Services.PRODUCT_BY_CATEGORY.rawValue)\(category.id)", callBack: function)
        }
    }
    
    
    static func getComment<T : Decodable>(product: Product, completition:@escaping ([T]?) -> Void,
                                          onError: ((String) -> Void)?){
        DispatchQueue.main.async {
           let service = Service(baseUrl: .ECOMMERCE)
            let function = {(data:[T]?, status: Bool, message:String) -> Void in
                if status {
                    completition(data)
                }
                else{
                    if let errorFuntion = onError{
                        errorFuntion("")
                    }
                }
            }
            print( "\(Services.PRODUCT_BY_CATEGORY.rawValue)\(product.id)")
            service.getAllItems(endPoint: "\(Services.COMMENT_BY_PRODUCT.rawValue)\(product.id)", callBack: function)
        }
    }
    
    static func Login<T : Decodable>(parameters:[String:Any], completition:@escaping (T?) -> Void,
                                          onError: ((String) -> Void)?){
        DispatchQueue.main.async {
           let service = Service(baseUrl: .ECOMMERCE)
            let function = {(data:T?, status: Bool, message:String) -> Void in
                if status {
                    if let dataTmp = data {
                        completition(dataTmp)
                    }
                    else{
                        if let errorFuntion = onError{
                            errorFuntion(message)
                        }
                    }
                }
                else{
                    if let errorFuntion = onError{
                        errorFuntion("")
                    }
                }
            }
            service.sendItems(data: parameters, endPoint: Services.LOGIN.rawValue, callBack: function)
        }
    }
    
    static func sendOrder<T : Decodable>(parameters:[String:Any], completition:@escaping (T?) -> Void,
                                          onError: ((String) -> Void)?){
        DispatchQueue.main.async {
            let service = Service(baseUrl: .ECOMMERCE)
            let function = {(data:T?, status: Bool, message:String) -> Void in
                if status {
                    completition(message as? T)
                }
                else{
                    if let errorFuntion = onError{
                        errorFuntion("")
                    }
                }
            }
            service.createItems(data: parameters, endPoint: Services.ORDER.rawValue, callBack: function)
        }
    }
    
    
    static func getOrder<T : Decodable>(endPoint: String,completition:@escaping ([T]?) -> Void,
                                          onError: ((String) -> Void)?){
        DispatchQueue.main.async {
            let service = Service(baseUrl: .ECOMMERCE)
            let function = {(data:[T]?, status: Bool, message:String) -> Void in
                if status {
                    if let dataTmp = data {
                        completition(dataTmp)
                    }
                    else{
                        if let errorFuntion = onError{
                            errorFuntion(message)
                        }
                    }
                }
                else{
                    if let errorFuntion = onError{
                        errorFuntion("")
                    }
                }
            }
            service.getAllItems(endPoint: endPoint, callBack: function)
        }
    }
    
    
    static func sendComment<T : Decodable>(parameters:[String:Any], completition:@escaping (T?) -> Void,
                                          onError: ((String) -> Void)?){
        DispatchQueue.main.async {
            let service = Service(baseUrl: .ECOMMERCE)
            let function = {(data:T?, status: Bool, message:String) -> Void in
                if status {
                    completition(message as? T)
                }
                else{
                    if let errorFuntion = onError{
                        errorFuntion("")
                    }
                }
            }
            service.createItems(data: parameters, endPoint: Services.CREATE_COMMENT.rawValue, callBack: function)
        }
    }
    
    
    static func CreateUser<T : Decodable>(parameters:[String:Any], completition:@escaping (T?) -> Void,
                                          onError: ((String) -> Void)?){
        DispatchQueue.main.async {
           let service = Service(baseUrl: .ECOMMERCE)
            let function = {(data:T?, status: Bool, message:String) -> Void in
                if status {
                    if let dataTmp = data {
                        completition(dataTmp)
                    }
                    else{
                        if let errorFuntion = onError{
                            errorFuntion(message)
                        }
                    }
                }
                else{
                    if let errorFuntion = onError{
                        errorFuntion("")
                    }
                }
            }
            service.sendItems(data: parameters, endPoint: Services.CREATE_USER.rawValue, callBack: function)
        }
    }
    
}
