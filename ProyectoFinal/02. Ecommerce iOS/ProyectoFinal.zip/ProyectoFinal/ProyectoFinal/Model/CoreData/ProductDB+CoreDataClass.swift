//
//  ProductDB+CoreDataClass.swift
//  
//
//  Created by MacBookDesarrolloTecno01 on 8/23/20.
//
//

import Foundation
import CoreData

@objc(ProductDB)
public class ProductDB: NSManagedObject {

}
