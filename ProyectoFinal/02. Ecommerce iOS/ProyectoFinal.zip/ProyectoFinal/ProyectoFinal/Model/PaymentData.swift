//
//  PaymentData.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/29/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
struct PaymentData: Codable{
    var card: String
    var expiration: String
    var cvv: String
    var description:[String:Any] {
        get {
            return ["card": self.card,
                    "expiration": self.expiration,
                    "cvv": self.cvv,
                ] as [String : Any]
        }
    }
}
