//
//  DesignManager.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/22/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
import UIKit

enum ButtonDesign{
    case FORM
}
enum ViewDesign{
    case HEADER
    case SUBTITLE
    case PRINCIPAL
    case PRODUCT_COLLECTION_CONTAINER
    case FILTER_CONTAINER
    case FILTER
    case BORDER_CELL
    case SEARCH_BAR
    case LOADER
    case BORDER
}
enum NavigationBarDesign{
    case PRINCIPAL
}

class DesignManager{
    static func buttonDesign(element: UIButton, type: ButtonDesign){
        switch type {
        case .FORM:
            element.backgroundColor = UIColor.init().ConvertHexString(hexString: "#335480")
            element.tintColor = UIColor.white
            element.layer.borderWidth = 1
            element.layer.cornerRadius = 5
            element.layer.cornerRadius = 5
            break        }
    }
    
    static func viewDesign(element: UIView, type: ViewDesign){
        switch type {
        case .HEADER:
            element.backgroundColor = UIColor.init().ConvertHexString(hexString: "#4F71B5")
            break
        case .SUBTITLE:
            element.backgroundColor = UIColor.init().ConvertHexString(hexString: "#4F71B5")
            element.layer.borderWidth = 1
            element.layer.borderColor = UIColor.white.cgColor
            break
        case .PRINCIPAL:
            element.backgroundColor = UIColor.init().ConvertHexString(hexString: "#94A8D8")
            break
        case .PRODUCT_COLLECTION_CONTAINER:
            //element.backgroundColor = UIColor.init().ConvertHexString(hexString: "#D2D2D2")
            element.backgroundColor = UIColor.systemGray5
            break
        case .FILTER_CONTAINER:
            element.backgroundColor = UIColor.init().ConvertHexString(hexString: "#D2D2D2")
            element.layer.borderWidth = 1
            element.layer.cornerRadius = 10
            break
        case .FILTER:
            element.backgroundColor = UIColor.white
            element.layer.borderWidth = 0
            element.layer.cornerRadius = 10
            break
        case .BORDER_CELL:
            element.layer.borderWidth = 1
            element.layer.cornerRadius = 10
            break
        case .BORDER:
            element.layer.borderWidth = 1
            element.layer.borderColor = UIColor.black.cgColor
            break
        case .SEARCH_BAR:
            element.backgroundColor = .white
            element.layer.borderWidth = 1
            element.layer.cornerRadius = 5.0
            element.layer.shadowRadius = 5
            element.layer.shadowOpacity = 0.1
            element.layer.shadowOffset = CGSize(width: 5, height: 5)
            break
        case .LOADER:
            element.backgroundColor = UIColor.init().ConvertHexString(hexString: "#F2272441").withAlphaComponent(0.95)
            break
        }
    }
    
    static func navigationBarDesign(element: UINavigationBar, type: NavigationBarDesign){
        switch type {
        case .PRINCIPAL:
            element.barTintColor = UIColor.init().ConvertHexString(hexString: "#4F71B5")
            element.tintColor = UIColor.white
            break
        }
    }
    
    static func base64ToImage(base64String: String?) -> UIImage?{
        guard let base64 = base64String else{return nil}
        if (base64.isEmpty) {
            return nil
        }else {
            let temp = base64.components(separatedBy: ",")
            if temp.count > 1{
                if let dataDecoded : Data = Data(base64Encoded: temp[1], options: .ignoreUnknownCharacters){
                    let decodedimage = UIImage(data: dataDecoded)
                    return decodedimage
                }
            }
        }
        return UIImage()
    }
    
}


extension UIColor  {
    
    func ConvertHexString (hexString:String) -> UIColor {
        
        var rgb: UInt32 = 0
        
        let s: Scanner = Scanner(string: hexString as String)
        
        s.scanLocation = 1
        
        s.scanHexInt32(&rgb)
        
        return UIColor(
            
            red: CGFloat((rgb & 0xFF0000) >> 16) / 255.0,
            
            green: CGFloat((rgb & 0x00FF00) >> 8) / 255.0,
            
            blue: CGFloat(rgb & 0x0000FF) / 255.0,
            
            alpha: CGFloat(1.0)
            
        )
        
    }
}
