//
//  ProductDB+CoreDataProperties.swift
//  
//
//  Created by MacBookDesarrolloTecno01 on 8/23/20.
//
//

import Foundation
import CoreData


extension ProductDB {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ProductDB> {
        return NSFetchRequest<ProductDB>(entityName: "ProductDB")
    }
    @NSManaged public var id: int16?
    @NSManaged public var name: String?
    @NSManaged public var price: NSDecimalNumber?
    @NSManaged public var category: String?
    @NSManaged public var image: String?
    @NSManaged public var brand: int16??

}
