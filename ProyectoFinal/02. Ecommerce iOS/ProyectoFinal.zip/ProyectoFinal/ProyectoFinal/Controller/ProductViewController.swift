//
//  ProductViewController.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/23/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import UIKit

class ProductViewController: BaseViewController {

    @IBOutlet weak var commentCollection: UICollectionView!
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var brandLbl: UILabel!
    @IBOutlet weak var colorLbl: UILabel!
    
    @IBOutlet weak var principalView: UIView!
    @IBOutlet weak var productContainerView: UIView!
    @IBOutlet weak var commentsContainerView: UIView!
    
    @IBOutlet weak var subTitleView: UIView!
    @IBOutlet weak var addBtn: UIButton!
    
    var product : Product? = nil
    
    var commentCollectionDelegate = CommentCollectionDelegate()
    
    var commentList : [Comment] = []{
        didSet{
            self.commentCollectionDelegate.listComments = self.commentList
            self.commentCollection.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.commentCollectionDelegate.vc = self
        self.commentCollection.dataSource = self.commentCollectionDelegate
        self.commentCollection.delegate = self.commentCollectionDelegate
        self.setDesign()
        if let data = self.product {
            self.setDataProduct(product: data)
            self.setDataComments(product: data)
        }
    }
    
    func setDataProduct(product: Product){
        self.title =  product.name
        self.nameLbl.text? = product.name
        self.priceLbl.text? = "Precio: ¢\(product.price)"
        self.brandLbl.text? = "Marca: ¢\(product.brand)"
        self.colorLbl.text? = "Color: ¢\(product.color)"
        if let image = DesignManager.base64ToImage(base64String: product.image){
            self.productImage.image =  image
        }
    }
    
    func setDesign(){
        DesignManager.viewDesign(element: self.productContainerView, type: .BORDER_CELL)
        DesignManager.viewDesign(element: self.principalView, type: .PRINCIPAL)
        DesignManager.buttonDesign(element: self.addBtn, type: .FORM)
        DesignManager.viewDesign(element: self.subTitleView, type: .SUBTITLE)
        
        DesignManager.viewDesign(element: self.commentsContainerView, type: .PRODUCT_COLLECTION_CONTAINER)
    }

    @IBAction func addProductAction(_ sender: Any) {
        if let data = self.product {
            if let _ = CoreDataManager.getProduct().first(where: {$0.id == product?.id }){
                self.showMessage(title: "No se puede agregar", message: "El producto ya está en el carrito", button: "Aceptar")
            }
            else{
                CoreDataManager.saveProduct(data: data)
                self.showMessage(title: "Genial!!!", message: "Se ha agregado el producto a tu Carrito", button: "Aceptar", completion: {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        self.navigationController?.popViewController(animated: true)
                    }
                })
            }
        }
        else{
            self.showError(error: "")
        }
        
    }
}


extension ProductViewController{
    func setDataComments(product: Product){
        self.showLoader()
        DataAccessManager.getComment(product: product, completition : self.setProducts, onError: self.showError)
    }
    
    func setProducts(data : [Comment]?){
        DispatchQueue.main.async {
            if let list = data{
                self.commentList = list
            }
            self.hideLoader()
        }
    }
}
