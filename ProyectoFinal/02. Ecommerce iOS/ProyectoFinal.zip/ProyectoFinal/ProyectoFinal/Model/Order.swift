//
//  Order.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/29/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
struct Order: Codable{
    var id: Int = 0
    var paymentData: PaymentData
    var user: User
    var productsID:[Int]
    var totalAmount: Decimal
    
    init(payment: PaymentData, user: User, productsData: [ProductDB], total: Decimal){
        self.paymentData = payment
        self.user = user
        self.totalAmount = total
        self.productsID = []
        for item in productsData {
            self.productsID.append(Int(item.id))
        }
    }
    
    var description:[String:Any] {
        get {
            return ["paymentData": self.paymentData.description,
                    "user": self.user.description,
                    "productsID": self.productsID.map{$0},
                    "totalAmount": self.totalAmount
                ] as [String : Any]
        }
    }
    
    
}

struct OrderResponse: Codable{
    var id: Int = 0
    var products: [ProductResponse]
    var totalAmount: Decimal
}
