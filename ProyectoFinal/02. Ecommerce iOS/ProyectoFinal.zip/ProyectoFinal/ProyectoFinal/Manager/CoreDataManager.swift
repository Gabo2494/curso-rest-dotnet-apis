//
//  CoreDataManager.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/23/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class CoreDataManager{
    
    static func saveProduct(data: Product){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context =  appDelegate.persistentContainer.viewContext
        
        let productEntity = NSEntityDescription.entity(forEntityName: "ProductDB", in: context)
        let product = NSManagedObject(entity: productEntity!, insertInto: context) as! ProductDB
        
        product.id = data.id
        product.image = data.image
        product.name = data.name
        product.price = NSDecimalNumber(decimal: data.price)
        product.brand = data.brand
        product.category = ""

        do {
            try context.save()
        }catch let error {
            print("Error \(error.localizedDescription)")
        }
    }
    
    static func getProduct() -> [ProductDB]{
        
        var products : [ProductDB] = []
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return products}
        let context =  appDelegate.persistentContainer.viewContext
        
        let request:NSFetchRequest<ProductDB> = ProductDB.fetchRequest()
        
        do{
            let productResults = try context.fetch(request)
            products = productResults
        }catch let error {
            print("Error \(error.localizedDescription)")
        }
        
        return products
    }
    
    static func deleteProduct(id : Int16){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let context =  appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "ProductDB")
        
        do{
            let tasks = try context.fetch(fetchRequest)
            
            for data in tasks {
                if let idData: Int16  = data.value(forKey: "id") as? Int16{
                    if idData == id{
                        context.delete(data)
                    }
                }
            }
            
            do {
                try context.save()
            }catch let error {
                print("Error \(error.localizedDescription)")
            }
            
        }catch let error {
            print("Error \(error.localizedDescription)")
        }
    }
    
    static func deleteAllProduct(){
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let context =  appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "ProductDB")
        
        do{
            let tasks = try context.fetch(fetchRequest)
            
            for data in tasks {
                context.delete(data)
            }
            
            do {
                try context.save()
            }catch let error {
                print("Error \(error.localizedDescription)")
            }
            
        }catch let error {
            print("Error \(error.localizedDescription)")
        }
        
    }
}
