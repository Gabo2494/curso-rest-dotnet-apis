//
//  CategoryCollectionDelegate.swift
//  ProyectoFinal
//
//  Created by MacBookDesarrolloTecno01 on 8/22/20.
//  Copyright © 2020 MarvinCalvo. All rights reserved.
//

import Foundation
import UIKit

class CategoryCollectionDelegate: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    
    var vc : BaseViewController?
    var categoryList : [Category]?
    var typeCell: String = "cell"
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.categoryList?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : CategoryCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: self.typeCell, for: indexPath) as! CategoryCollectionViewCell
        if let listData = self.categoryList{
            cell.setData(data: listData[indexPath.row])
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 100, height: collectionView.bounds.height - 20)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let searchVC = (UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ResultItemSearchViewController") as! ResultItemSearchViewController)
        if let list = self.categoryList{
            searchVC.categorySelect = list[indexPath.row]
        }
        vc?.navigationController?.pushViewController(searchVC, animated: true)
    }
    
}
